using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Terraria.Localization;

namespace JourneysReborn.NPCs
{
    public class NPCBuffsRework : GlobalNPC
    {
        public override void SetDefaults(NPC target) {
            if(npc.type == NPCID.SolarCorite || npc.type == NPCID.SolarSpearman || npc.type == NPCID.SolarDrakomire ||
                    npc.type == NPCID.SolarDrakomireRider || npc.type == NPCID.SolarSolenian || npc.type == NPCID.SolarSroller ||
                    npc.type == NPCID.SolarCrawltipedeHead || npc.type == NPCID.SolarCrawltipedeBody || npc.type == NPCID.SolarCrawltipedeTail) {
                        target.buffImmune[BuffID.OnFire] = true;
                        target.buffImmune[BuffID.OnFire3] = true;
            };
            
        }

        public override void OnHitPlayer(NPC npc, Player target, Player.HurtInfo info)
        {
            if((npc.type == NPCID.Vampire || npc.type == NPCID.VampireBat) && !target.GetModPlayer<VampireProtection>().vampireProtection) {
                npc.HealEffect(info.Damage / 6);
                npc.life += info.Damage / 6;
            };

            if(Main.expertMode) {
                if(npc.type == NPCID.AncientLight) {
                    target.AddBuff(BuffID.Silenced, 600, true);
                };
                if(npc.type == NPCID.AncientDoom) {
                    target.AddBuff(BuffID.WitheredWeapon, 900, true);
                };
            };

            if(npc.type == NPCID.SwampThing) {
                target.AddBuff(BuffID.Poisoned, 1800, true);
            };

            if(npc.type == NPCID.Herpling) {
                if(Main.rand.NextBool(1, 5)) {
                    target.AddBuff(BuffID.Confused, 300, false);
                };
            };

            if(npc.type == NPCID.Mothron) {
                if(Main.rand.NextBool(1, 3)) {
                    target.AddBuff(BuffID.Blackout, 3600, false);
                };
            };

            if(npc.type == NPCID.CreatureFromTheDeep) {
                if(Main.rand.NextBool(1, 3)) {
                    target.AddBuff(BuffID.OgreSpit, 240, false);
                };
            };

            if(npc.type == NPCID.PossessedArmor) {
                if(Main.rand.NextBool(1, 7)) {
                    target.AddBuff(BuffID.BrokenArmor, 1980, false);
                };
            };

            if(npc.type == NPCID.VampireBat) {
                if(Main.rand.NextBool(1, 10)) {
                    target.AddBuff(BuffID.Rabies, 7200, false);
                };
            };

            if(npc.type == NPCID.PirateGhost) {
                target.AddBuff(BuffID.Cursed, 600, true);
            };

            if(npc.type == NPCID.SporeBat || npc.type == NPCID.SporeSkeleton ||
                npc.type == NPCID.ZombieMushroom || npc.type == NPCID.ZombieMushroomHat) {
                    if(Main.rand.NextBool(1, 5)) {
                        target.AddBuff(BuffID.Weak, 1200, false);
                };
            };

            if(npc.type == NPCID.Vulture) {
                if(Main.rand.NextBool(1, 8)) {
                    target.AddBuff(BuffID.Bleeding, 900, false);
                };
            };

            if(npc.type == NPCID.Moth) {
                target.AddBuff(BuffID.Poisoned, 1200, true);
            };

            if(npc.type == NPCID.Wolf) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Bleeding, 1620, false);
                };
            };

            if(npc.type == NPCID.BloodZombie || npc.type == NPCID.Drippler) {
                if(Main.rand.NextBool(1, 2)) {
                    target.AddBuff(BuffID.Bleeding, 1200, false);
                };
            };

            if(npc.type == NPCID.CorruptBunny ||
                npc.type == NPCID.CorruptGoldfish ||
                npc.type == NPCID.CorruptPenguin) {
                    if(Main.rand.NextBool(1, 6)) {
                        target.AddBuff(BuffID.WitheredWeapon, 1200, false);
                    };
            };
            if(npc.type == NPCID.CrimsonBunny ||
                npc.type == NPCID.CrimsonGoldfish ||
                npc.type == NPCID.CrimsonPenguin ||
                npc.type == NPCID.BloodJelly) {
                    if(Main.rand.NextBool(1, 4)) {
                        target.AddBuff(BuffID.Bleeding, 1200, false);
                    };
            };
            if(npc.type == NPCID.BloodFeeder) {
                if(Main.rand.NextBool(3)) {
                    target.AddBuff(BuffID.Bleeding, 900, false);
                };
            };

            if(npc.type == NPCID.Hellbat) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 3)) {
                        target.AddBuff(BuffID.OnFire, 240, false);
                    };
                };
            };
            if(npc.type == NPCID.Lavabat) {
                if(Main.expertMode) {
                    target.AddBuff(BuffID.OnFire, 300, true);
                };
            };

            if(npc.type == NPCID.Fritz) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 6)) {
                        target.AddBuff(BuffID.PotionSickness, 1800, false);
                    };
                };
            };

            if(npc.type == NPCID.GiantFlyingFox) {
                if(Main.expertMode) {
                    target.AddBuff(BuffID.Rabies, 1800, true);
                };
            };

            if(npc.type == NPCID.GiantTortoise) {
                if(Main.rand.NextBool(2, 7)) {
                    target.AddBuff(BuffID.Slow, 900, false);
                };
            };
            if(npc.type == NPCID.IceTortoise) {
                if(Main.rand.NextBool(2, 11)) {
                    target.AddBuff(BuffID.Chilled, 540, false);
                };
            };

            if(npc.type == NPCID.Derpling) {
                if(Main.rand.NextBool(2, 5)) {
                    target.AddBuff(BuffID.Weak, 1800, false);
                };
            };

            if(npc.type == NPCID.Snatcher || npc.type == NPCID.ManEater) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 3)) {
                        target.AddBuff(BuffID.Silenced, 600, false);
                    };
                };
            };
            if(npc.type == NPCID.AngryTrapper) {
                if(Main.expertMode) {
                    target.AddBuff(BuffID.Silenced, 1500, true);
                };
            };

            if(Main.expertMode) {
                if(npc.type == NPCID.FaceMonster || npc.type == NPCID.BloodCrawler || npc.type == NPCID.BloodCrawlerWall) {
                    if(Main.rand.NextBool(1, 6)) {
                        target.AddBuff(BuffID.Bleeding, 720, false);
                    };
                };
                if(npc.type == NPCID.DevourerHead || npc.type == NPCID.DevourerBody || npc.type == NPCID.DevourerHead ||
                    npc.type == NPCID.SeekerHead || npc.type == NPCID.SeekerBody || npc.type == NPCID.SeekerTail) {
                    if(Main.rand.NextBool(1, 6)) {
                        target.AddBuff(BuffID.Weak, 600, false);
                    };
                };
            };

            if(npc.type == NPCID.Tumbleweed) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 5)) {
                        target.AddBuff(BuffID.Slow, 360, false);
                    };
                };
            };

            if(npc.type == NPCID.EaterofWorldsHead || npc.type == NPCID.EaterofWorldsBody || npc.type == NPCID.EaterofWorldsTail) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 3)) {
                        target.AddBuff(BuffID.Confused, 720, false);
                    };
                };
            };

            if(npc.type == NPCID.Shark) {
                target.AddBuff(BuffID.Bleeding, 1200, true);
            };

            if(npc.type == NPCID.Mummy) {
                if(Main.rand.NextBool(1, 8)) {
                    target.AddBuff(BuffID.Cursed, 360, false);
                };
            };

            if(npc.type == NPCID.DesertBeast) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 8)) {
                        target.AddBuff(BuffID.Stoned, 480, false);
                    };
                };
            };

            if(npc.type == NPCID.WalkingAntlion || npc.type == NPCID.FlyingAntlion) {
                if(Main.rand.NextBool(1, 7)) {
                    target.AddBuff(BuffID.Poisoned, 300, false);
                };
            };
            if(npc.type == NPCID.GiantWalkingAntlion || npc.type == NPCID.GiantFlyingAntlion) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Poisoned, 600, false);
                };
            };

            if(npc.type == NPCID.Unicorn) {
                target.AddBuff(BuffID.Slow, 900, true);
                if(npc.damage < 600) {
                    npc.damage += 120;
                };
            };

            if(npc.type == NPCID.Corruptor || npc.type == NPCID.FloatyGross) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 3)) {
                        target.AddBuff(BuffID.Weak, 3600, true);
                    };
                };
            };
            if(npc.type == NPCID.VileSpit) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 3)) {
                        target.AddBuff(BuffID.OgreSpit, 600, false);
                    };
                };
            };

            if(npc.type == NPCID.CursedHammer || npc.type == NPCID.CrimsonAxe || npc.type == NPCID.EnchantedSword) {
                if(Main.expertMode) {
                    target.AddBuff(BuffID.Cursed, 600, true);
                };
                if(Main.rand.NextBool(1, 5)) {
                    target.AddBuff(npc.type == NPCID.CursedHammer ? BuffID.WitheredArmor : (npc.type == NPCID.CrimsonAxe ? BuffID.Bleeding : BuffID.Slow), 480, false);
                };
            };

            if(npc.type == NPCID.SeekerHead || npc.type == NPCID.SeekerBody || npc.type == NPCID.SeekerTail) {
                if(Main.rand.NextBool(1, 6)) {
                    target.AddBuff(BuffID.CursedInferno, 240, true);
                };
            };

            if(Main.expertMode) {
                if(npc.type == NPCID.SolarCorite || npc.type == NPCID.SolarSpearman || npc.type == NPCID.SolarDrakomire ||
                    npc.type == NPCID.SolarDrakomireRider || npc.type == NPCID.SolarSolenian || npc.type == NPCID.SolarSroller ||
                    npc.type == NPCID.SolarCrawltipedeHead || npc.type == NPCID.SolarCrawltipedeBody || npc.type == NPCID.SolarCrawltipedeTail) {
                        if(Main.rand.NextBool(1, 3)) {
                            target.AddBuff(BuffID.Burning, 300, true);
                        };
                }
            };

            if(npc.type == NPCID.BlazingWheel) {
                target.AddBuff(BuffID.Burning, 240, true);
            };

            if(npc.type == NPCID.Moth) {
                if(Main.masterMode) {
                    if(Main.rand.NextBool(1, 2)) {
                        target.AddBuff(ModContent.BuffType<Inhibition>(), 1500, true);
                    };
                } else if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 3)) {
                        target.AddBuff(ModContent.BuffType<Inhibition>(), 1200, true);
                    };
                } else {
                    if(Main.rand.NextBool(1, 4)) {
                        target.AddBuff(ModContent.BuffType<Inhibition>(), 600, true);
                    };
                };
            }
        }

        public override void OnHitNPC(NPC npc, NPC target, NPC.HitInfo info)
        {  
            if(npc.type == NPCID.Vampire || npc.type == NPCID.VampireBat) {
                if(npc.type == NPCID.Truffle) {
                    npc.AddBuff(BuffID.Confused, 600, true);
                } else {
                    npc.HealEffect(target.lifeMax / 15 + info.Damage, true);
                    npc.life = target.lifeMax / 15 + info.Damage;
                };
            };
        }

    public class ProjectileLoader : GlobalProjectile
    {
        public override void OnHitPlayer(Projectile projectile, Player target, Player.HurtInfo info)
        {
            if(projectile.type == ProjectileID.EyeBeam) {
                target.AddBuff(BuffID.Ichor, 1200, true);
            };

            if(projectile.type == ProjectileID.RuneBlast) {
                if(Main.rand.NextBool(1, 3)) {
                    target.AddBuff(BuffID.CursedInferno, 300, false);
                };
            };

            if(projectile.type == ProjectileID.DesertDjinnCurse) {
                target.AddBuff(BuffID.WitheredArmor, 1800, false);
            };

            if(projectile.type == ProjectileID.UnholyTridentHostile) {
                if(Main.rand.NextBool(1, 3)) {
                    target.AddBuff(BuffID.WitheredArmor, 1800, false);
                };
            };

            if(projectile.type == ProjectileID.DrManFlyFlask) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Confused, 420, false);
                };
            };

            if(projectile.type == ProjectileID.RockGolemRock) {
                if(Main.expertMode) {
                    if(Main.rand.NextBool(1, 6)) {
                        target.AddBuff(BuffID.BrokenArmor, 3600, false);
                    };
                };
            };

            if(Main.expertMode) {
                if(projectile.type == ProjectileID.CultistBossIceMist) {
                    target.AddBuff(BuffID.Chilled, 600, true);
                };
                if(projectile.type == ProjectileID.CultistBossLightningOrbArc) {
                    target.AddBuff(BuffID.Electrified, 300, true);
                };
                if(projectile.type == ProjectileID.CultistBossFireBallClone) {
                    target.AddBuff(BuffID.WitheredArmor, 900, true);
                };
                if(projectile.type == ProjectileID.Stinger) {
                    if(Main.rand.NextBool(1, 8)) {
                        target.AddBuff(ModContent.BuffType<Inhibition>(), 600, false);
                    };
                };
            };

            if(projectile.type == ProjectileID.GeyserTrap) {
                if(Main.expertMode && !Main.masterMode) {
                    target.AddBuff(BuffID.OnFire, 360, true);
                };
                if(Main.masterMode) {
                    target.AddBuff(BuffID.OnFire3, 360, true);
                };
            };
        }

        public override void ModifyHitNPC(Projectile projectile, NPC target, ref NPC.HitModifiers modifiers)
        {
            if(projectile.type == ProjectileID.SilverCoin && npc.type == NPCID.Werewolf) {
                modifiers.FlatBonusDamage += 50;
                modifiers.SetCrit();
            };

            if(projectile.type == ProjectileID.CrystalLeafShot) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Poisoned, 1800, false);
                };
            };

            if(projectile.type == ProjectileID.SporeCloud || projectile.type == ProjectileID.ChlorophyteOrb) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Poisoned, 900, false);
                };
            };

            if(projectile.type == ProjectileID.ToxicCloud ||
                projectile.type == ProjectileID.ToxicCloud2 ||
                projectile.type == ProjectileID.ToxicCloud3) {
                if(Main.rand.NextBool(1, 5)) {
                    target.AddBuff(BuffID.Confused, 60, false);
                };
            };

            if(projectile.type == ProjectileID.FrostDaggerfish) {
                if(Main.rand.NextBool(1, 3)) {
                    target.AddBuff(BuffID.Frostburn, 240, false);
                };
            };

            if(projectile.type == ProjectileID.Shroomerang) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Confused, 40, false);
                };
            };

            if(projectile.type == ProjectileID.IceBoomerang) {
                if(Main.rand.NextBool(1, 4)) {
                    target.AddBuff(BuffID.Frostburn, 180, false);
                };
            };

            if(projectile.type == ProjectileID.HellfireArrow) {
                if(Main.rand.NextBool(1, 3)) {
                    target.AddBuff(BuffID.OnFire, 240, false);
                };
            };
        }
    }
}