using Terraria;
using Terraria.ID;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace ReflourishedJourney.Content.Items.Accessories
{
    [AutoloadEquip(EquipType.Shoes)]
	public class HadesBoots : ModItem
	{
		public override void SetStaticDefaults() {
			base.SetStaticDefaults();
			CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
		}

		public override void SetDefaults() {
			Item.width = 34;
			Item.height = 28;
			Item.value = Item.buyPrice(gold: 30);
			Item.rare = ItemRarityID.LightPurple;
			Item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual) 
{
        player.rocketBoots = 3;
        player.accRunSpeed = 6.5f;
        player.noFallDmg = true;
        player.fireWalk = true;
        player.flameWakerBoots = true;
    }
}