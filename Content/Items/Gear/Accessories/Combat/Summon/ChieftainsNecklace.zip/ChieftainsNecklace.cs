using Terraria;
using Terraria.ID;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;
using System;

namespace JourneysReborn.Content.Items.Gear.Accessories.Combat.Summon
{
	[AutoloadEquip(EquipType.Neck)]
	public class ChieftainsNecklace : ModItem
	{
		public override void SetStaticDefaults() {
			base.SetStaticDefaults();
			CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
		}

		public override void SetDefaults() {
			Item.width = 28;
			Item.height = 28;
			Item.value = Item.buyPrice(gold: 22);
			Item.rare = ItemRarityID.Lime;
			Item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual) {
            var modPlayer = player.GetModPlayer<ChieftainsNecklacePlayer>();
            modPlayer.ChieftainsNecklace = true;
		}

        public override void AddRecipes() {
            CreateRecipe()
                .AddIngredient(ItemID.PygmyNecklace)
                .AddIngredient(ItemID.Leather, 6)
                .AddIngredient(ItemID.Diamond, 8)
                .AddIngredient(ItemID.Amber, 8)
                .AddIngredient(ItemID.Amethyst, 4)
                .AddIngredient(ItemID.Emerald, 4)
                .AddTile(TileID.TinkerersWorkbench)
				.Register();
		}
	}
	
	public class ChieftainsNecklacePlayer : ModPlayer
    {
        // Флаг, что аксессуар надет
        public bool ChieftainsNecklace;

        // Сохраняем значения бонусов для использования в других классах
        public int summonTagDamageBonus;
        public int minionDefenseIgnore;

        public override void ResetEffects()
        {
            // Сбрасываем каждый тик
            ChieftainsNecklace = false;
            summonTagDamageBonus = 0;
            minionDefenseIgnore = 0;
        }

        public override void UpdateEquips()
        {
            if (ChieftainsNecklace)
            {
                // +1 миньон
                Player.maxMinions += 1;

                // +2 к урону от summon tag
                Player.SummonTagDamage += 2;

                // Запоминаем значение игнорирования защиты (5)
                minionDefenseIgnore = 5;
            }
        }
    }
	
	public class MinionDefenseGlobalProjectile : GlobalProjectile
    {
        public override void ModifyHitNPC(Projectile projectile, NPC target, ref int damage, ref float knockback, ref bool crit)
        {
            // Проверяем, является ли снаряд миньоном (или стражем)
            if (projectile.minion || projectile.sentry)
            {
                Player owner = Main.player[projectile.owner];
                if (owner.active && !owner.dead)
                {
                    var modPlayer = owner.GetModPlayer<ChieftainsNecklacePlayer>();
                    if (modPlayer.minionDefenseIgnore > 0)
                    {
                        int defense = target.defense;
                        if (defense > 0)
                        {
                            // Добавляем к урону ровно столько, сколько защита позволяет игнорировать
                            int ignore = Math.Min(defense, modPlayer.minionDefenseIgnore);
                            damage += ignore;
                        }
                    }
                }
            }
        }
    }
}